# 微信小程序原生开发-开源项目

> 该仓库是关于微信小程序原生开发的所有开源仓库地址，由UP主咸虾米提供，该仓库主要作为引导使用，包含如下模块；
>
> 1.相关项目的仓库地址；
>
> 2.视频学习地址；
>
> 3.体验该项目；
>
> 请给个star吧，代码不断升级项目案例不断开发，请大家持续关注，也可以进入QQ群，有新的项目，会在群里提醒的，Q群：770479352。

![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-3309c116-4743-47d6-9979-462d2edf878c/0b7fa2fa-06ed-4aa5-bca7-b3f29157a58f.png)

------



## 🚀一、微信小程序包熟，零基础入门

![输入图片说明](weixinBase/%E7%B4%A0%E6%9D%90%E8%B5%84%E6%96%99/banner.jpg)

#### 🏆 视频学习地址：

##### [https://www.bilibili.com/video/BV19G4y1K74d](https://www.bilibili.com/video/BV19G4y1K74d)

####  📚 仓库地址：

##### https://gitee.com/qingnian8/weixinNative/tree/master/weixinBase

#### ✨ 小程序体验码： 
![输入图片说明](weixinBase/%E7%B4%A0%E6%9D%90%E8%B5%84%E6%96%99/XZS.jpg)

------



## 🚀二、微信小程序云开发，基础入门篇

![](https://gitee.com/qingnian8/weixinNative/raw/master/cloudBase/%E7%B4%A0%E6%9D%90%E8%B5%84%E6%96%99/cloudbase.jpg)

#### 🏆 视频学习地址：

https://www.bilibili.com/video/BV1MY411Y7Ak

#### 📚 仓库地址：

https://gitee.com/qingnian8/weixinNative/tree/master/cloudBase

------



## 🚀三、小程序云开发商城实战项目

![](cloudBase/素材资料/mall.jpg)

#### 🏆 视频学习地址：

http://suo.nz/36io7A

